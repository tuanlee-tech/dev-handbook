# 🧬 Evolution Map Prompt Template v2
> Reusable prompt để học lịch sử tiến hóa của bất kỳ techstack nào.
> Chỉ cần điền phần **CONTEXT** rồi gửi toàn bộ cho AI.

---

## 📌 HƯỚNG DẪN SỬ DỤNG

1. Copy toàn bộ phần trong khung `---` bên dưới
2. Điền đầy đủ **CONTEXT BLOCK** (càng cụ thể AI càng trả lời tốt)
3. Gửi cho AI — không cần chỉnh gì thêm

---


## 🧬 Yêu cầu: Evolution Map — [TÊN_TECHSTACK]

---

### 📌 CONTEXT (tôi đã điền, đọc kỹ trước khi trả lời)

| Trường | Giá trị |
|---|---|
| Techstack | [TÊN_TECHSTACK] |
| Vai trò trong hệ thống | [frontend / backend / devops / database / testing / tooling] |
| Khía cạnh cụ thể cần học | [ví dụ: async patterns, component model, state management, routing, ORM queries...] |
| Legacy cũ nhất cần maintain | [phiên bản hoặc khoảng năm — ví dụ: "v4.x" hoặc "dự án từ ~2018"] |
| Target version hiện tại | [phiên bản mới nhất team đang dùng hoặc "latest stable"] |
| Kiến thức nền đã có | [ví dụ: "biết JS ES6+, đã dùng React hooks cơ bản, chưa biết gì về Redux"] |

---

### 🎯 MỤC TIÊU CỦA TÔI

1. Đọc hiểu và maintain legacy code mà không tự hiểu sai
2. Nhận ra ngay một codebase cũ đang dùng pattern của era nào
3. Biết khi nào nên và không nên refactor khi làm việc với code cũ
4. Viết code mới theo best practices hiện tại

---

### 📋 FORMAT BẮT BUỘC — 5 SECTIONS THEO ĐÚNG THỨ TỰ

---

#### SECTION 1 — EVOLUTION TIMELINE

Liệt kê các **phiên bản / paradigm shift** quan trọng theo thứ tự thời gian.

Với **MỖI mốc**, cung cấp đủ 4 thông tin:

- **📅 Thời điểm:** năm ra mắt và phiên bản cụ thể
- **🔴 Pain point:** vấn đề gì của phiên bản/cách làm TRƯỚC ĐÓ đã thúc đẩy sự thay đổi này (đây là lý do tồn tại của phiên bản mới — KHÔNG ĐƯỢC bỏ qua)
- **✅ Giải pháp:** điều gì phiên bản này giải quyết được
- **🏷️ Phân loại:**
  - ⭐ **CẦN HỌC KỸ** — vẫn dùng rộng rãi trong production, cần biết để maintain và viết mới
  - 📖 **CẦN ĐỌC HIỂU** — còn gặp trong codebase cũ khi refactor, cần đọc được nhưng không cần viết mới
  - 💀 **CHỈ CẦN BIẾT TÊN** — đã khai tử hoàn toàn, không còn ai dùng, chỉ nhắc để tôi không bối rối khi đọc tài liệu cũ

> ⚠️ KHÔNG giải thích khái niệm cơ bản. Tập trung vào ĐỘNG LỰC thay đổi và ĐIỀU GÌ đã thay đổi.

---

#### SECTION 2 — VERSION FINGERPRINTING

**"Tôi mở một codebase không biết version — nhận ra ngay đây là era nào?"**

Đây là section THỰC TIỄN NHẤT cho người maintain legacy. Với MỖI phiên bản ⭐ và 📖, liệt kê các **dấu hiệu nhận dạng** điển hình:

```
[Era / Phiên bản X — Năm Y đến Năm Z]
Nhận ra qua:
  Syntax / import style: [ví dụ cụ thể]
  Package / dependency:  [tên package đặc trưng của era này]
  Config file:           [file config, format đặc trưng nếu có]
  Idiom hay gặp:         [1-2 pattern code điển hình của era này]
```

Ví dụ thực tế nhỏ (1-3 dòng code) cho mỗi idiom nếu cần.

---

#### SECTION 3 — OLD vs NEW: SO SÁNH TRỰC TIẾP

Với MỖI cặp phiên bản liền kề (📖 → ⭐), cung cấp:

**A. Code cũ:**
```[ngôn ngữ]
// Era: [tên phiên bản cũ] — phổ biến trong codebase [~năm]
// 🔴 Vấn đề khi maintain: [2-3 vấn đề thực tế, cụ thể]
[code thực tế, đủ để compile/chạy — KHÔNG dùng pseudo-code]
```

**B. Code mới:**
```[ngôn ngữ]
// Era: [tên phiên bản mới]
// ✅ Cải tiến: [2-3 lợi ích cụ thể so với code cũ ở trên]
[code tương đương — CÙNG chức năng, chỉ khác cách viết]
```

**C. Bảng so sánh** — chọn các tiêu chí THỰC SỰ PHÙ HỢP với [TÊN_TECHSTACK], không cần cố định:

| Tiêu chí | Cách cũ | Cách mới |
|---|---|---|
| [Tiêu chí quan trọng nhất với techstack này] | | |
| [Tiêu chí thứ 2] | | |
| [Tiêu chí thứ 3] | | |
| Có thể coexist trong cùng project? | [có/không và trông như thế nào] | — |
| Nên migrate khi nào? | — | [điều kiện cụ thể] |

> **📝 Coexistence note:** Nếu code cũ và mới CÓ THỂ cùng tồn tại trong một project (ví dụ class components + hooks trong cùng React app), mô tả rõ:
> - Trông như thế nào trong thực tế
> - Quy tắc nào nên đặt ra để tránh hỗn loạn

---

#### SECTION 4 — MIGRATION GUIDE

Với MỖI phiên bản 📖 → ⭐:

**Step-by-step refactor** (nếu cần migrate):
1. [Bước cụ thể 1]
2. [Bước cụ thể 2]
3. ...

**🛑 Khi KHÔNG nên migrate** (quan trọng không kém khi nào nên):
- Các trường hợp cụ thể nên giữ nguyên code cũ
- Rủi ro thực tế khi refactor mù quáng
- Dấu hiệu nhận ra "code này trông cũ nhưng để yên là đúng"

**🚨 False friends** — cú pháp trông GIỐNG NHAU nhưng hoạt động KHÁC NHAU:
```[ngôn ngữ]
// ⚠️ Hai đoạn này trông tương đương nhưng KHÔNG phải:

// Cách cũ (era X):
oldPattern(arg)
// Kết quả/behavior: [mô tả cụ thể]

// Cách mới (era Y) — cùng syntax nhưng semantic khác:
newPattern(arg)
// Kết quả/behavior: [mô tả cụ thể — CHỈ RÕ điểm khác biệt]
```

**💥 Breaking changes quan trọng** (nếu có):
Liệt kê ngắn gọn theo format: `vX → vY: [điều gì break, cách fix]`

---

#### SECTION 5 — QUICK REFERENCE CARD

Bảng tra cứu nhanh — **không cần đọc, chỉ cần scan.**
Dùng khi đọc code cũ và gặp pattern lạ, tra ngay ở đây.

| Pattern gặp trong code cũ | Era / Version | Ý nghĩa | Modern equivalent |
|---|---|---|---|
| [pattern 1] | [v?.x ~ năm] | [giải thích ngắn] | [tương đương hiện tại] |
| [pattern 2] | | | |
| [pattern 3] | | | |
| ... | | | |

> Cung cấp tối thiểu **8–10 pattern** phổ biến nhất của [TÊN_TECHSTACK].
> Ưu tiên những pattern khó đoán hoặc dễ gây hiểu lầm nhất.

---

### ✅ SELF-CHECK TRƯỚC KHI KẾT THÚC

Trước khi hoàn thành response, kiểm tra nội tâm và bổ sung nếu thiếu:
- Section 1: Mỗi mốc có đủ pain point + giải pháp + phân loại chưa?
- Section 2: Mỗi era ⭐/📖 có fingerprint nhận dạng được chưa?
- Section 3: Code demo có thực tế (compile/chạy được) không? Đã cover hết cặp cũ-mới chưa?
- Section 4: Đã nêu cả "khi nào NÊN" lẫn "khi nào KHÔNG NÊN" migrate chưa?
- Section 5: Bảng có ≥ 8 rows không?

Nếu thiếu section nào → bổ sung trước khi trả lời.

