# 🎓 Course Generator Prompt — Fullstack Techstack
> Prompt sinh khóa học hoàn chỉnh cho bất kỳ techstack nào.
> Tích hợp Evolution Map methodology làm xương sống của mỗi bài học.

---

## ⚡ QUICK START — 3 bước

1. **Điền CONTEXT BLOCK** bên dưới (càng cụ thể AI output càng tốt)
2. **Chọn MODE** phù hợp với việc bạn cần làm ngay
3. **Copy toàn bộ prompt → gửi cho AI**

**Workflow khuyến nghị:**
```
MODE A (outline) → MODE B [0.1] (Module 0: orientation + evolution map)
→ MODE E [0] (quiz kiểm tra baseline)
→ MODE B [1.1] → B [1.2] → ... (học từng bài)
→ MODE C [1] (luyện tập sau mỗi module)
→ MODE D [mini-1] (project sau 2-3 module)
→ MODE E [1] (quiz trước khi sang module tiếp)
→ ... lặp lại cho module tiếp theo ...
→ MODE D [capstone] (project cuối khóa)
```

---

```
## 🎓 Yêu cầu: Course Generator — [TÊN_TECHSTACK]

---

### 📌 CONTEXT (tôi đã điền, đọc kỹ trước khi trả lời)

| Trường | Giá trị |
|---|---|
| Techstack | [TÊN_TECHSTACK] |
| Vai trò trong hệ thống | [frontend / backend / devops / database / testing / tooling] |
| Khía cạnh cụ thể cần học | [state management / async / routing / ORM / CI pipeline / ...] |
| Legacy cũ nhất cần maintain | [phiên bản hoặc khoảng năm — ví dụ: "v4.x" hoặc "dự án từ ~2018"] |
| Target version | [phiên bản mới nhất team dùng hoặc "latest stable"] |
| Kiến thức nền đã có | [ví dụ: "biết JS ES6+, biết React hooks cơ bản, chưa biết Redux"] |
| Mục tiêu chính | [ ] Học để maintain legacy  [ ] Học để viết code mới  [ ] Cả hai |
| Thời gian tự học/tuần | [ví dụ: "2 giờ/ngày × 5 ngày"] |

---

### 🎮 MODE — chọn MỘT rồi điền tham số

| Mode | Lệnh | Dùng khi nào |
|---|---|---|
| **A** | `COURSE OUTLINE` | Bắt đầu học, cần xem toàn bộ curriculum |
| **B** | `LESSON [x.y]` | Học bài x.y (x = module, y = bài trong module) |
| **C** | `EXERCISE SET [x]` | Luyện tập sau khi học xong module x |
| **D** | `PROJECT [mini-x]` hoặc `PROJECT [capstone]` | Làm project thực hành (mini = nhỏ, capstone = cuối khóa) |
| **E** | `QUIZ [x]` | Kiểm tra kiến thức module x trước khi tiếp tục |

**→ Mode đang chọn:** `MODE ___ : [tham số]`

---

### 📐 TIÊU CHUẨN TOÀN KHÓA (áp dụng mọi mode)

- **Code phải thực tế:** compile/chạy được, không dùng pseudo-code
- **Mỗi khái niệm phải có evolution context:** pain point của cách cũ → lý do cách mới ra đời — KHÔNG ĐƯỢC bỏ qua dù khái niệm có vẻ đơn giản
- **Ngôn ngữ:** tiếng Việt cho prose, tiếng Anh cho code và technical terms
- **Breaking changes:** nếu có, PHẢI chỉ rõ version cụ thể (`vX → vY: [điều gì break]`)
- **Độ khó tăng dần:** trong cùng bài và giữa các module
- **Phân loại era:** mỗi ví dụ code phải ghi rõ thuộc era/version nào

---

### 📋 FORMAT THEO TỪNG MODE

---

#### MODE A — COURSE OUTLINE

Tạo toàn bộ cấu trúc khóa học. Output gồm 3 phần:

**A1. Course Summary**
- Mô tả: khóa này dạy gì, cho ai, đạt được gì sau khi xong
- Tổng thời gian ước tính (dựa trên "thời gian học/tuần" trong context)
- Cách sử dụng khóa học này hiệu quả nhất (dùng các MODE A→E như thế nào)

**A2. Curriculum Table**

| Module | Tên Module | Lessons (tóm tắt) | Era/Version liên quan | Thời gian | Ưu tiên |
|---|---|---|---|---|---|
| 0 | Orientation & Evolution Map | 0.1 Why this tech exists / 0.2 Full evolution timeline / 0.3 Version fingerprinting | All eras | ~2h | ⭐ Bắt buộc |
| 1 | [Tên module 1] | 1.1 ... / 1.2 ... / 1.3 ... | [vX.x – vY.y] | ~?h | ⭐/📖/💡 |
| ... | | | | | |
| N | Capstone Project | | Latest | ~?h | ⭐ Bắt buộc |

Phân loại ưu tiên:
- ⭐ **Bắt buộc** — core, không thể bỏ
- 📖 **Nên học** — quan trọng nhưng có thể học sau
- 💡 **Mở rộng** — nâng cao, học khi có thời gian

**A3. Study Paths — chọn theo mục tiêu chính**

*Path A — Maintain Legacy:* module nào học trước, module nào có thể skip/học sau
*Path B — Viết code mới:* module nào học trước, module nào có thể skip/học sau
*Path C — Cả hai:* lộ trình cân bằng theo thứ tự ưu tiên

---

#### MODE B — LESSON [x.y]

Dạy một bài cụ thể. Output theo thứ tự 6 phần sau:

**B1. Lesson Header**
- Mã bài: Module [x] — Lesson [y]
- Tiêu đề bài học
- Prerequisites: bài nào cần hoàn thành trước
- Thời gian ước tính
- Learning Objectives: "Sau bài này, bạn có thể..."
  - [Động từ đo lường được + kết quả cụ thể] × 3–5 objectives

**B2. Evolution Context** ← BẮT BUỘC, không được bỏ

Trả lời 3 câu hỏi:
1. 🔴 **Pain point:** Vấn đề gì của cách làm trước đó thúc đẩy sự thay đổi này?
2. ✅ **Giải pháp:** Feature/pattern này giải quyết được gì?
3. 📅 **Timeline:** Ra đời khi nào, thay thế cái gì?

**B3. Core Concept + Code Progression**

Giải thích ngắn gọn (không dài dòng), sau đó demo code theo progression từ cũ → mới:

```[ngôn ngữ]
// ❌ ERA CŨ: [tên era / version] — phổ biến ~[năm]
// 🔴 Vấn đề khi maintain: [2-3 vấn đề cụ thể]
[code thực tế — đủ compile/chạy]
```

```[ngôn ngữ]
// ✅ ERA MỚI: [tên era / version]
// ✅ Cải tiến: [2-3 lợi ích cụ thể, đối chiếu trực tiếp với vấn đề ở trên]
[code tương đương — CÙNG chức năng, chỉ khác cách viết]
```

> Nếu có nhiều hơn 2 bước tiến hóa trong bài này, demo từng bước theo thứ tự thời gian.

**B4. Pitfalls & False Friends**

3–5 lỗi/hiểu nhầm phổ biến nhất. Với mỗi pitfall:

```[ngôn ngữ]
// ❌ SAI — hay gặp ở người mới học từ era cũ
saiPattern()
// Vấn đề: [giải thích tại sao sai/nguy hiểm]

// ✅ ĐÚNG
dungPattern()
```

Đặc biệt chú ý **False Friends** — cú pháp trông GIỐNG nhau nhưng behavior KHÁC nhau giữa các version.

**B5. Practice Exercises** (2–3 bài)

Với mỗi bài:
- **[Easy/Medium/Hard]** — [Tên bài]
- Yêu cầu: [mô tả bài toán thực tế, không abstract]
- Constraints: [dùng/không dùng gì]
- Expected output: [kết quả cụ thể]
- 💡 Hints: [1-2 gợi ý không spoil solution]
- *Solution: yêu cầu riêng nếu cần — "Cho tôi solution bài [x.y]-[số bài]"*

**B6. Summary**
- 3–5 bullet điểm then chốt cần nhớ (không phải tóm tắt toàn bài)
- Connection: "Bài này liên quan đến [bài/module X] vì..."
- Next: "Bài tiếp theo [x.y+1] sẽ xây dựng trên khái niệm..."

---

#### MODE C — EXERCISE SET [x]

Tạo bộ bài tập cho module x. 4 loại bài tập, mỗi loại 1–2 bài:

**C1. Coding Exercise** — Viết từ đầu
- Problem: [scenario thực tế, không abstract]
- Constraints: [phải dùng concepts từ module x]
- Expected output: [cụ thể, có thể verify]
- 💡 Hints (2–3 gợi ý theo mức độ, từ ít spoil đến nhiều)
- Solution: [code đầy đủ + giải thích từng phần quan trọng]

**C2. Debugging Exercise** — Tìm và sửa bug
```[ngôn ngữ]
// ⚠️ Code dưới đây có [N] bug. Tìm tất cả và giải thích tại sao sai.
[code có lỗi thực tế — không dùng bug giả tạo]
```
- Solution: [chỉ rõ từng bug + giải thích + code đúng]

**C3. Refactoring Exercise** — Nâng cấp legacy code
```[ngôn ngữ]
// 📖 ERA CŨ: [version] — code này viết theo style ~[năm]
// Nhiệm vụ: refactor sang [target version] theo modern best practices
[legacy code thực tế]
```
- Yêu cầu refactor: [cụ thể cần đổi gì]
- Lưu ý khi migrate: [gotchas cần biết]
- Solution: [code đã refactor + giải thích từng thay đổi]

**C4. Code Reading Exercise** — Đọc hiểu legacy code
```[ngôn ngữ]
// 📖 ERA: [version ~năm] — bạn gặp đoạn code này trong codebase cũ
[legacy code thực tế, đủ phức tạp để cần giải thích]
```
Trả lời 3–4 câu hỏi:
1. Đoạn code này làm gì?
2. Pattern/idiom nào của era [X] đang được dùng?
3. Nếu viết lại bằng [target version], trông như thế nào?
4. [Câu hỏi cụ thể về behavior nếu cần]

---

#### MODE D — PROJECT

**Mini Project [mini-x]** (1–3 buổi học):
- **Brief:** scenario 1 đoạn, đủ để có context thực tế
- **Must-have features:** (3–5 requirements)
- **Technical constraints:** bắt buộc dùng concepts từ Module [X, Y, ...]
- **Step-by-step guide:** 4–6 bước, mỗi bước có hint nếu bị stuck
- **Evaluation checklist:** tự check bằng tiêu chí cụ thể (pass/fail, không phải cảm tính)

**Capstone Project [capstone]** (cuối khóa, 3–5 buổi):
- **Brief:** scenario phức tạp, realistic, cover đa số concepts đã học
- **Features:**
  - Must-have: (5–7 requirements — bắt buộc hoàn thành)
  - Nice-to-have: (3–4 requirements — bonus)
- **Architecture notes:** gợi ý cấu trúc, không prescriptive
- **Phase plan:**
  - Phase 1 — [tên]: [mục tiêu + deliverable]
  - Phase 2 — [tên]: [mục tiêu + deliverable]
  - Phase 3 — [tên]: [mục tiêu + deliverable]
  - Phase 4 — [tên nếu cần]: [mục tiêu + deliverable]
- **Evaluation rubric:** scoring guide cụ thể (không phải "tốt/chưa tốt")

---

#### MODE E — QUIZ [x]

Kiểm tra kiến thức module x. Output gồm 2 phần:

**E1. Quiz — 8 câu, mix 4 loại:**

*Loại 1 — Conceptual MCQ* (2–3 câu)
Câu hỏi về "tại sao" và "khi nào dùng", không phải thuộc lòng syntax.
4 lựa chọn, 1 đúng. Các lựa chọn sai phải plausible (gây confusion thực sự).

*Loại 2 — Code Reading* (2–3 câu)
Cho đoạn code legacy hoặc modern, hỏi về behavior/output.
Format: "Đoạn code sau làm gì?" hoặc "Output là gì?"

*Loại 3 — Fill in the Blank* (2 câu)
```[ngôn ngữ]
// Hoàn thiện đoạn code sau để [đạt kết quả X]:
const result = ________(data)
  .________(item => item.active)
  .________(item => item.value);
```

*Loại 4 — Short Explanation* (1 câu)
Giải thích ngắn (3–5 câu) tại sao [concept A] thay thế [concept B] trong [techstack].
Chú trọng "tại sao" chứ không phải "như thế nào".

**E2. Self-grading Guide:**
- Đáp án đầy đủ + giải thích cho từng câu
- "Nếu sai câu [số]: review lại bài [x.y] — phần [tên phần]"
- Pass threshold: [N]/8 để tiếp tục sang module tiếp theo
- Dưới threshold: "Review lại [danh sách bài cụ thể] trước khi tiếp tục"

---

### ✅ AI SELF-CHECK (bắt buộc trước khi kết thúc)

Kiểm tra nội tâm — bổ sung nếu phát hiện thiếu:

**Mọi mode:**
- Context đã đọc kỹ chưa? Output có match với target version và level chưa?
- Ngôn ngữ đúng chưa? (Vietnamese prose + English code/terms)
- Code examples thực tế (không phải pseudo-code)?

**Mode B cụ thể:**
- Section B2 (Evolution Context) có đủ 3 câu hỏi không? Không được bỏ qua.
- Code progression có ghi rõ era/version không?
- Pitfalls có include False Friends nếu relevant không?

**Mode C cụ thể:**
- Đủ 4 loại exercise không? (Coding, Debugging, Refactoring, Code Reading)
- Debugging exercise có code lỗi thực tế không (không phải lỗi giả tạo)?

**Mode E cụ thể:**
- Đủ 8 câu, đủ 4 loại không?
- MCQ có 4 lựa chọn plausible không (không phải 1 đúng + 3 rõ ràng sai)?
- Self-grading guide có chỉ rõ bài cần review khi sai không?

Nếu phát hiện thiếu → bổ sung trước khi kết thúc response.


---

## 🔄 QUAN HỆ VỚI EVOLUTION MAP v2


| | Evolution Map v2 | Course Generator v1 |
|---|---|---|
| **Mục đích** | Reference document — đọc một lần, tra lại khi cần | Interactive course — học, luyện, kiểm tra |
| **Output** | 5 sections: Timeline, Fingerprinting, Old vs New, Migration, Quick Ref | 5 modes: Outline, Lesson, Exercise, Project, Quiz |
| **Evolution context** | Core feature — toàn bộ document xoay quanh đây | Baked into mọi lesson (Section B2 bắt buộc) |
| **Code examples** | Old vs New, explain sự khác biệt | Old vs New + Debugging + Refactoring exercises |
| **Active recall** | Không có | Quiz + Exercises + Projects |
| **Khi nào dùng** | Khi cần "bản đồ nhanh" về một techstack | Khi cần học từ đầu, có structure + practice |



**Recommended workflow:**
> Dùng **Evolution Map v2** trước để có bức tranh tổng thể (30–60 phút)
> → Sau đó dùng **Course Generator** để đi vào chiều sâu từng phần
